
import json


from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

uri = "mongodb+srv://sabih562:MM7mY0pZ2nixoBM6@cluster0.1hrnt5z.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))


def load_to_db():
    file_path = '/content/ETL_Pipeline_Sabih_DS-59/data/cleaned_data.json'
    try:
        # Open the file and load the data as a dictionary
        with open(file_path, 'r') as file:
            data = json.load(file)

        db = client['weather_data']  # 'weather_data' will be created if it doesn't exist

        # Access (or create) the collection within that database
        collection = db['temperature_readings']  # 'temperature_readings' will be created if it doesn't exist

        collection.insert_many(data)

    except FileNotFoundError:
        print(f"Error: The file at {file_path} was not found.")
    except json.JSONDecodeError:
        print(f"Error: The file at {file_path} is not a valid JSON.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")


def main():
  load_to_db()

