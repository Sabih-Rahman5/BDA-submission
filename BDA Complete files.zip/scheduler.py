
import time
import threading
import etl_pipeline

# Scheduler to run the ETL function at intervals
def scheduler(interval_seconds):
    while True:
        etl_pipeline.main()  # Call the ETL function
        time.sleep(interval_seconds)  # Wait for the interval before calling again

# Function to start the scheduler in a new thread
def start_scheduler(interval_seconds):
    scheduler_thread = threading.Thread(target=scheduler, args=(interval_seconds,))
    scheduler_thread.daemon = True  # Daemon thread will exit when the main program exits
    scheduler_thread.start()

# Run the scheduler every 300 seconds (as an example)
if __name__ == "__main__":
    start_scheduler(10)  # Set the interval to 300 seconds(5 mins)

    # Keep the main program alive to let the scheduler run
    while True:
        time.sleep(1)
